package com.Project3.Project3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
