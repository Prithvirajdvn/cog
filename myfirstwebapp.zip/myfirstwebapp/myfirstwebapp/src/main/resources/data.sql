insert into Todo(ID, USER_NAME, DESCRIPTION, TARGET_DATE, DONE) values (1001,'Nani', 'Learn java Now!', CURRENT_DATE(), false);

insert into Todo(ID, USER_NAME, DESCRIPTION, TARGET_DATE, DONE) values (1002,'Nani', 'Learn Python Now!', CURRENT_DATE(), false);
insert into Todo(ID, USER_NAME, DESCRIPTION, TARGET_DATE, DONE) values (1003,'Nani', 'Learn AWS Now!', CURRENT_DATE(), false);
insert into Todo(ID, USER_NAME, DESCRIPTION, TARGET_DATE, DONE) values (1004,'Nani', 'Learn Azure Now!', CURRENT_DATE(), false);