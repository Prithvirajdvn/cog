<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html>
<head>
    <title>Access Denied</title>
    <link href="webjars/bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .container {
            margin-top: 50px; /* Increased margin for better vertical centering */
            text-align: center;
        }
        .error-icon {
            font-size: 100px; /* Increased size of the icon */
            color: #dc3545; /* Red color for error */
            margin-bottom: 20px;
        }
        .message {
            font-size: 24px; /* Increased font size for the message */
            margin-bottom: 30px;
        }
        .home-button {
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <%@ include file="common/header.jspf" %>
    <div class="container">
        <i class="fas fa-exclamation-triangle error-icon"></i> <%-- Use a Font Awesome icon --%>
        <h1 class="message">Access Denied</h1>
        <p>You do not have permission to access this resource.</p>
        <a href="/" class="btn btn-primary home-button">Go to Home Page</a>
    </div>

    <script src="webjars/jquery/3.6.0/jquery.min.js"></script>
    <script src="webjars/bootstrap/5.1.3/js/bootstrap.min.js"></script>
    <script src="https://kit.fontawesome.com/your-font-awesome-kit.js"></script> <%-- Include Font Awesome --%>
    <script>
        $(document).ready(function() {
            // Optional: You can add custom JavaScript here if needed.
        });
    </script>
    <%@ include file="common/footer.jspf" %>
</body>
</html>
