
<%@ include file="common/header.jspf" %>
<div class="container">
	<h1>Enter The New Todo </h1>
	<form:form method="post" modelAttribute="todo">
		<fieldset class="mb-3">
			<form:label path="description">Description</form:label>
			<form:textarea path="description" required="required" class="form-control"></form:textarea>
			<form:errors path="description" cssClass="text-warning"/>
		</fieldset>
		
		<fieldset class="mb-3">
			<form:label path="targetDate">Target Date</form:label>
			<form:input type="text" path="targetDate" required="required"></form:input>
			<form:errors path="targetDate" cssClass="text-warning"/>
		</fieldset>
		
		
		<form:input type="hidden" path="id" class="id"/>
		<form:input type="hidden" path="done"  class="done"/>
		<button type="submit" class="btn btn-primary">Submit</button>
	</form:form>
</div>

	
<%@ include file="common/footer.jspf" %>

<script type="text/javascript">
	$('#targetDate').datepicker({
	    format: 'yyyy-mm-dd'
	});
</script>







