<%@ include file="common/header.jspf" %>
<div class="container">
	<h1>Hi There. Your Todo List </h1>
	<table class="table">
		<thead>
			<!-- <tr><th>Id</th> -->
			<th>Description</th>
			<th>targetDate</th>
			<th>Done</th>
			<th>Update</th>
			<th>Delete</th>
			</tr>
			
		</thead>
		<tbody>
		<c:forEach items="${todos}" var="todo">
			<tr>
				<%-- <td>${todo.id}</td> --%>
				<td>${todo.description}</td>
				<td>${todo.targetDate}</td>
				<td>${todo.done}</td>
				<td><a href="todo-update?id=${todo.id} " class="btn btn-primary">UPDATE</a></td>
				<td><a href="todo-delete?id=${todo.id} " class="btn btn-warning">DELETE</a></td>
			</tr>
		</c:forEach>
		</tbody>
			
			</table>
	<a href="add-todo" class="btn btn-success">AddTodo</a>
</div>
<%@ include file="common/footer.jspf" %>