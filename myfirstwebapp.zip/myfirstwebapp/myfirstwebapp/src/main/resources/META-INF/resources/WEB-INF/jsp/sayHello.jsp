<%@ include file="common/header.jspf" %>
	<div class="container">
		<h1>Hello to ${name}. From JSP page</h1>
		<p>Your password is ${pass}</p>
		<a href="/admin/list-todos">Todos</a>
	</div>
<%@ include file="common/footer.jspf" %>