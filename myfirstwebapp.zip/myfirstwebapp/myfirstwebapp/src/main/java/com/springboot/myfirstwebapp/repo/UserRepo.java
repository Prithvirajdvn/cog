package com.springboot.myfirstwebapp.repo;
// required
import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.myfirstwebapp.entity.Users;

public interface UserRepo extends JpaRepository<Users, Integer>{

	Users findByUsername(String username);
//	Optional<Users> findByUsername(String username);

}
