package com.springboot.myfirstwebapp.service;

// required
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.springboot.myfirstwebapp.entity.Users;
import com.springboot.myfirstwebapp.repo.UserRepo;

import java.util.Optional;

@Service
public class Userservice {
	
	@Autowired
	UserRepo repo;

	private BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
	public Users register(Users user) {
		user.setPassword(encoder.encode(user.getPassword()));
		repo.save(user);
		return user;
	}

	public Users getUserByUsername(String username) {
		Users user =(repo.findByUsername(username));
		return user; // Or throw an exception if user not found: .orElseThrow(() -> new UserNotFoundException("User not found: " + username));
	}
}
