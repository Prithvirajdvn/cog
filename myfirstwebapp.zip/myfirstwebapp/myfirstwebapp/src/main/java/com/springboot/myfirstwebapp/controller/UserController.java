package com.springboot.myfirstwebapp.controller;

import com.springboot.myfirstwebapp.service.JwtService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.web.bind.annotation.*;
import com.springboot.myfirstwebapp.entity.Users;
import com.springboot.myfirstwebapp.service.Userservice;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/user")
@CrossOrigin
public class UserController {

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtService jwtService;

	@Autowired
	private Userservice service;

	@PostMapping("/login")
	public ResponseEntity<Map<String, Object>> login(@RequestParam("username") String username, @RequestParam("password") String password, HttpServletRequest request) {
		try {
			System.out.println("Entered");
			Authentication authentication = authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(username, password));
			SecurityContextHolder.getContext().setAuthentication(authentication);
			System.out.println("Exit");
			String roles = authentication.getAuthorities().stream()
					.map(GrantedAuthority::getAuthority)
					.collect(Collectors.joining(", "));

			// Fetch user details from the database.  Assuming you have a UserService.
			Users user = service.getUserByUsername(username); //  <--  ADDED THIS LINE

			System.out.println(username + " " + password + " - Login successful, Roles: " + roles + ", Session ID: " + request.getSession().getId());

			Map<String, Object> responseBody = new HashMap<>(); // Changed to Map<String, Object>
			responseBody.put("token", jwtService.generateToken(username));
			responseBody.put("message", "Login successful!");
			responseBody.put("username", username); // Add username
			responseBody.put("roles", roles);    // Add roles
			responseBody.put("userId", user.getId()); // Add user ID (assuming your User class has an getId() method)
//			responseBody.put("email", user.getEmail());
			// Add other relevant user data here (e.g., email, ID, etc.)
			request.getSession(true); // Ensure a session is created after successful authentication

			System.out.println(username + " " + password + " - Login successful, Session ID: " + request.getSession().getId() + " JWT=" + jwtService.generateToken(username));
			return ResponseEntity.ok(responseBody);
			//        return jwtService.generateToken(username);
		} catch (AuthenticationException e) {

			System.err.println("Login failed for user: " + username + " - " + e.getMessage());
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Login failed: " + e.getMessage()));
			//        return "error";
		}
	}

	// Removed the custom /login POST endpoint

	@PostMapping("/register")
	public Users register(@RequestBody Users user) {
		service.register(user);
		return user;
	}

	@GetMapping("/greet")
	public String greetAdmin() {
		return "Hello, Administrator!";
	}

	@PostMapping("/logout")
	public ResponseEntity<String> logout(HttpServletRequest request, HttpServletResponse response) {
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null) {
			new SecurityContextLogoutHandler().logout(request, response, authentication);
			return ResponseEntity.ok("Logout successful!");
		} else {
			return ResponseEntity.ok("No user logged in to logout.");
		}
	}

	@GetMapping("/data")
//	@PreAuthorize("hasRole('ROLE_ADMIN')")
	public ResponseEntity<String> getSecuredData() {
		// This endpoint should only be accessible to authenticated users.
		//  You might want to add additional authorization checks here.
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		if (authentication != null && authentication.isAuthenticated()) {
			String username = authentication.getName(); // Get the username of the logged-in user.
			System.out.println(username);
			return ResponseEntity.ok("This is secured data for secured users");
		} else {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized");
		}
//		return "Secured Data";
	}
}
