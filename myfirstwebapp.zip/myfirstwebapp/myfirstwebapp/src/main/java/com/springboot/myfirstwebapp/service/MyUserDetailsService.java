package com.springboot.myfirstwebapp.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.springboot.myfirstwebapp.entity.Users;
import com.springboot.myfirstwebapp.repo.UserPrincipal;
import com.springboot.myfirstwebapp.repo.UserRepo;

@Service
public class MyUserDetailsService implements UserDetailsService{
	
	@Autowired
	UserRepo repo;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		Users user=repo.findByUsername(username);
		System.out.println(user);
		if(user==null) {
			System.out.println("bad Credentials");
			throw new UsernameNotFoundException("Bad Credentials");
		}
		return new UserPrincipal(user);
	}

}
