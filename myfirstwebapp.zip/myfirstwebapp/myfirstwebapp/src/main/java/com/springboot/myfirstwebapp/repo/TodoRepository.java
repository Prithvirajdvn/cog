package com.springboot.myfirstwebapp.repo;

// not required
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.springboot.myfirstwebapp.entity.Todo;

public interface TodoRepository extends JpaRepository<Todo, Integer>{

	public List<Todo> findByUserName(String userName);
}
