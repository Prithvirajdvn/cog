package com.springboot.myfirstwebapp.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.*;

import org.springframework.stereotype.Service;

import com.springboot.myfirstwebapp.entity.Todo;

import jakarta.validation.Valid;

import java.time.LocalDate;

//@Service
public class TodoService {
	private static List<Todo> todos=new ArrayList<Todo>();
	
	private static int todoCount=3;
	
	static {
		todos.add(new Todo(1, "nani", "Learn Java Now 1", LocalDate.now().plusYears(1), false));
		todos.add(new Todo(2, "nani", "Learn Python Now 1", LocalDate.now().plusYears(2), false));
		todos.add(new Todo(3, "nani", "Learn C# Now! 1", LocalDate.now().plusYears(6), false));

	}
	
	public List<Todo> findByUserName(String userName){
//		Predicate<? super Todo> predicate = todo -> todo.getUserName().equalsIgnoreCase(userName);
//		return todos.stream().filter(predicate).toList();
		
		 List<Todo> filteredTodos = new ArrayList<>();
		    for (Todo todo : todos) {
		        if (todo.getUserName().equalsIgnoreCase(userName)) {
		            filteredTodos.add(todo);
		        }
		    }
		    return filteredTodos;
	}
	
	public void addTodo(String userName,String description,LocalDate targetDate, boolean done) {
		todos.add(new Todo(++todoCount, userName, description, targetDate, done));
	}
	
	public void deleteTodo(int id) {
//		Predicate<? super Todo> predicate= todo->todo.getId()==id;
//		todos.removeIf(predicate);
		
		for(Todo i:todos) {
			if(i.getId()==id) {
				todos.remove(i);
				break;
			}
		}
	}

	public Todo findById(int id) {
		// TODO Auto-generated method stub
		for(Todo i:todos) {
			if(i.getId()==id) {
				return i;
			}
		}
		return null;
		

//		Predicate<? super Todo> predicate = todo -> todo.getId() == id;
//		Optional<Todo> result = 
//.		todos.stream().map(this::updateTodo).forEach(System.out::println);
		
	}

	public void updateTodo(@Valid Todo todo) {
		// TODO Auto-generated method stub
		deleteTodo(todo.getId());
		todos.add(todo);
	}
}
