package com.springboot.myfirstwebapp.login;

// not required
import java.util.Collection;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
//@RestController
public class WelcomeController {
	

//	@RequestMapping(value="/", method=RequestMethod.GET)
	@GetMapping("/")
	public String gotoWelcomePage(ModelMap model) {
		model.put("name", getLoggedInUserName());
		return "sayHello";
	}
	
	@RequestMapping(value="/accessDenied", method=RequestMethod.GET)
	public String gotoErrorPage(ModelMap model) {
		model.put("name", getLoggedInUserName());
		return "accessDenied";
	}
	
	private String getLoggedInUserName() {
		
		Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
		Collection<? extends GrantedAuthority> c = authentication.getAuthorities();
		return authentication.getName();
		
	}
}
