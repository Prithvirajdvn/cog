package com.springboot.myfirstwebapp.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

//import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.springboot.myfirstwebapp.entity.Todo;
import com.springboot.myfirstwebapp.service.TodoService;

import jakarta.validation.Valid;

//@Controller
public class TodoController {
	
	@Autowired
	private TodoService todoService;
	
	
	
	public TodoController(TodoService todoService) {
		super();
		this.todoService = todoService;
	}



	@RequestMapping("list-todos")
	public String listAllTodos(ModelMap model) {
		
		String userName=getLoggedInUsername(model);
		List<Todo> todos=todoService.findByUserName(userName);
		model.put("todos",todos);
		return "listTodos";
	}



	private String getLoggedInUsername(ModelMap model) {
		Authentication authentication= SecurityContextHolder.getContext().getAuthentication();
		return authentication.getName();
	}
	
	@RequestMapping(value="add-todo", method=RequestMethod.GET)
	public String showNewTodoPage(ModelMap model) { // binding from server to web page (one way binding)
		String username=getLoggedInUsername(model);
		Todo todo=new Todo(0, username, "12345678i9op7i", LocalDate.now().plusYears(12), false);
		model.put("todo", todo);
		return "todo";
	}
	

	@RequestMapping(value="add-todo", method=RequestMethod.POST) // binding from webpage to server(two way binding) 
	public String addNewTodoPage(ModelMap model, @Valid Todo todo, BindingResult result) { // biding result should follow the attribute you want to bind
		
		
		if (result.hasErrors()) {
			System.out.println("Error"+result);
			return "todo";
	    }

		String userName = getLoggedInUsername(model);
		
		todoService.addTodo(userName, todo.getDescription(), todo.getTargetDate(), false);
		return "redirect:list-todos";
	}
	
	
	@RequestMapping(value="todo-delete", method=RequestMethod.GET)
	public String deleteTodo(@RequestParam int id) { // binding from server to web page (one way binding)
		todoService.deleteTodo(id);
		return "redirect:list-todos";
	}
	
	@RequestMapping(value="todo-update", method=RequestMethod.GET)
	public String showUpdateTodoPage(@RequestParam int id, ModelMap model) { // binding from server to web page (one way binding)
		Todo todo=todoService.findById(id);
		model.put("todo", todo);
		return "todo";
	}
	
	@RequestMapping(value="todo-update", method=RequestMethod.POST) // binding from webpage to server(two way binding) 
	public String updateTodoPage(ModelMap model, @Valid Todo todo, BindingResult result) { // biding result should follow the attribute you want to bind
		
		
		if (result.hasErrors()) {
			System.out.println("Error"+result);
			return "todo";
	    }

		String userName = getLoggedInUsername(model);
		
		todoService.updateTodo(todo);
		todo.setUserName(userName);
		return "redirect:list-todos";
	}

	
}
