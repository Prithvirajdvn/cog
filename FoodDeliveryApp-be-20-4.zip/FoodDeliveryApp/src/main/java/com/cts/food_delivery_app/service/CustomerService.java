package com.cts.food_delivery_app.service;
	
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cts.food_delivery_app.dto.CustomerDto;
import com.cts.food_delivery_app.dto.CustomerLoginDto;
import com.cts.food_delivery_app.dto.JwtDto;
import com.cts.food_delivery_app.entities.Customer;

import jakarta.validation.Valid;

public interface CustomerService {

	List<Customer> getAllCustomers();
	Customer getCustomerById(int customerId);
	ResponseEntity<Customer> createCustomer(CustomerDto customerDto);
    ResponseEntity<Customer> deleteCustomer(int customerId);
	ResponseEntity<JwtDto> checkLogin(@Valid CustomerLoginDto dto);
	ResponseEntity<Customer> changeUserDetails(@Valid CustomerDto customerDto);
	String getRoleByEmail(String email);
	CustomerDto getCustomerByEmail(String email);
}
