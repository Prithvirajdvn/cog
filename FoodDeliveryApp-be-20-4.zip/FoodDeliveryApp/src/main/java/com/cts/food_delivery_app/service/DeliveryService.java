package com.cts.food_delivery_app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cts.food_delivery_app.dto.DeliveryDto;

public interface DeliveryService
{
		List<DeliveryDto> getAllDeliveries(int agentId);

		DeliveryDto getDeliveryById(int deliveryId);

		DeliveryDto createDelivery(DeliveryDto deliveryDto);

		String deleteDelivery(int deliveryId);
		
		ResponseEntity<DeliveryDto> inProgressOrder(int deliveryId);

	    ResponseEntity<DeliveryDto> deliveredOrder(int deliveryId);
}


