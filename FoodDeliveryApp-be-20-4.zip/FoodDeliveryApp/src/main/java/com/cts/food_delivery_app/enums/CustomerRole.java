package com.cts.food_delivery_app.enums;

public enum CustomerRole {
	

 USER,ADMIN,AGENT
}
