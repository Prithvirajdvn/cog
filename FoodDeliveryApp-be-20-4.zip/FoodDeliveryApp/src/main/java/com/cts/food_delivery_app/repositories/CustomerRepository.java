package com.cts.food_delivery_app.repositories;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.RequestParam;

import com.cts.food_delivery_app.entities.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	public Optional<Customer> findByEmail(String email);

	@Query("SELECT c.role FROM Customer c WHERE c.email = :email")
    String findRoleByEmail(@RequestParam("email") String email);
 

}

