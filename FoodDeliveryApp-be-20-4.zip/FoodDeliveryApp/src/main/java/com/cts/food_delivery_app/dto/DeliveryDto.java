package com.cts.food_delivery_app.dto;


import com.cts.food_delivery_app.enums.DeliveryStatus;

import java.util.Date;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class DeliveryDto {
	
	@NotNull(message="deliveryId is required")
	private int deliveryId;
	
	@NotNull(message="orderId is required")
	private int orderId;
	
	@NotNull(message="AgentId is required")
	private int agentId;
	
	@NotNull(message="arrival time cannot be null")
    @Future(message = "Time slot start must be in the future")
	private Date estimatedTimeOfArrival;
	
	private DeliveryStatus status;
}
