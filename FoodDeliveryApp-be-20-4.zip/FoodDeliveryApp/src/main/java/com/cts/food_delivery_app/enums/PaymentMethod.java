package com.cts.food_delivery_app.enums;

public enum PaymentMethod {
UPI,COD,CREDITCARD
}
