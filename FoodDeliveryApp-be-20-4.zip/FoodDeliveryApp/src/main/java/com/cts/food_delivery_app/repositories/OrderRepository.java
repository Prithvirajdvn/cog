package com.cts.food_delivery_app.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.food_delivery_app.dto.OrderDto;
import com.cts.food_delivery_app.entities.Order;

public interface OrderRepository extends JpaRepository<Order, Integer> {
    List<Order> findByCustomer_CustomerId(int customerId);
}
