package com.cts.food_delivery_app.dto;

import com.cts.food_delivery_app.entities.Order;
import com.cts.food_delivery_app.enums.PaymentMethod;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class PaymentDto {
	
	@NotNull(message="paymentId is required")
	private int paymentId;
	
	@NotNull(message="orderId is required")
	private int orderId;
	
	@NotNull(message="Select a payment method")
	private PaymentMethod paymentMethod;
	
	private double amount;
	
	private String paymentStatus;

}
