package com.cts.food_delivery_app.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.cts.food_delivery_app.dto.MenuDto;
import com.cts.food_delivery_app.dto.OrderDto;

public interface OrderService {
    List<OrderDto> getAllOrders(int customerId);

    OrderDto getOrderById(int orderId);

    OrderDto createOrder(OrderDto orderDto);

    boolean deleteOrder(int orderId);

    ResponseEntity<OrderDto> pendingOrder(int orderId);

    ResponseEntity<OrderDto> acceptedOrder(int orderId);

    ResponseEntity<OrderDto> preparingOrder(int orderId);

    ResponseEntity<OrderDto> deliveredOrder(int orderId);
}
