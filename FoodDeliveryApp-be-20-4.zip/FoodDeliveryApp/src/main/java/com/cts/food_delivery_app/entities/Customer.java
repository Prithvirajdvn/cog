package com.cts.food_delivery_app.entities;

import com.cts.food_delivery_app.enums.CustomerRole;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Customer")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Customer {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int customerId;
	
	@Enumerated(value=EnumType.STRING)
	@Column(name="role")
	private CustomerRole role;

	private String name;
	
	@Column(nullable = false, unique = true)
	private String email;
	
	// @JsonProperty(access = Access.WRITE_ONLY)
	private String password;
	
	@Column(name="phone",columnDefinition="CHAR(10)",nullable = false, unique = true)
	private String phone;
	
	private String address;
	
}
