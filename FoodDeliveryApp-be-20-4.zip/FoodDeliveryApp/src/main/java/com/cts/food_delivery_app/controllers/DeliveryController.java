package com.cts.food_delivery_app.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.cts.food_delivery_app.dto.DeliveryDto;
import com.cts.food_delivery_app.dto.OrderDto;
import com.cts.food_delivery_app.service.DeliveryService;
import com.cts.food_delivery_app.service.OrderService;

import java.util.List;

@RestController
@RequestMapping("/deliveries")
public class DeliveryController {
    @Autowired
    private DeliveryService deliveryService;

    @GetMapping("/getAll/{agentId}")
    //@PreAuthorize("hasAuthority('AGENT')")
    public ResponseEntity<List<DeliveryDto>> getAllDeliveries(@PathVariable("agentId") int agentId) {
        List<DeliveryDto> deliveries = deliveryService.getAllDeliveries(agentId);
        return ResponseEntity.ok(deliveries);
    }

    @GetMapping("/{deliveryId}")
    //@PreAuthorize("hasAuthority('AGENT')")
    public ResponseEntity<DeliveryDto> getDeliveryById(@PathVariable int deliveryId) {
        DeliveryDto deliveryDto = deliveryService.getDeliveryById(deliveryId);
        if (deliveryDto != null) {
            return ResponseEntity.ok(deliveryDto);
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/create")
    //@PreAuthorize("hasAuthority('AGENT')")
    public ResponseEntity<DeliveryDto> createDelivery(@RequestBody DeliveryDto deliveryDto) {
        DeliveryDto createdDelivery = deliveryService.createDelivery(deliveryDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdDelivery);
    }

    @DeleteMapping("/{deliveryId}")
    //@PreAuthorize("hasAuthority('AGENT')")
    public ResponseEntity<String> deleteDelivery(@PathVariable int deliveryId) {
        deliveryService.deleteDelivery(deliveryId);
        return ResponseEntity.noContent().build();
    }
    
    @PutMapping("/inprogress/{deliveryId}")
    //@PreAuthorize("hasAuthority('AGENT')")
    public ResponseEntity<DeliveryDto> updateToInProgress(@PathVariable("deliveryId") int deliveryId) {
        return deliveryService.inProgressOrder(deliveryId);
    }

    @PutMapping("/delivered/{deliveryId}")
    //@PreAuthorize("hasAuthority('AGENT')")
    public ResponseEntity<DeliveryDto> updateToDelivered(@PathVariable("deliveryId") int deliveryId) {
        return deliveryService.deliveredOrder(deliveryId);
    }
}
