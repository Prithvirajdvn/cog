package com.cts.food_delivery_app.controllers;

 
import java.util.List;
 
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;

import org.springframework.security.access.prepost.PreAuthorize;

import org.springframework.web.bind.annotation.*;
 
import com.cts.food_delivery_app.dto.MenuDto;

import com.cts.food_delivery_app.dto.OrderDto;

import com.cts.food_delivery_app.service.OrderService;
 
@RestController

@RequestMapping("/orders")

public class OrderController {

    @Autowired

    private OrderService orderService;
 
    @PostMapping("/create/order")

    //@PreAuthorize("hasAuthority('USER')")

    public ResponseEntity<OrderDto> createOrder(@RequestBody OrderDto order) {

        OrderDto createdOrder = orderService.createOrder(order);

        return new ResponseEntity<>(createdOrder, HttpStatus.CREATED);

    }

    @GetMapping("/getAll/{customerId}")

    //@PreAuthorize("hasAuthority('USER')")

    public ResponseEntity<List<OrderDto>> getAllOrders(@PathVariable("customerId") int customerId) {

        List<OrderDto> orders = orderService.getAllOrders(customerId);

        return new ResponseEntity<>(orders, HttpStatus.OK);

    }
 
    @GetMapping("/{orderId}")

    public ResponseEntity<OrderDto> getOrderById(@PathVariable("orderId") int orderId) {

        OrderDto order = orderService.getOrderById(orderId);

        if (order != null) {

            return new ResponseEntity<>(order, HttpStatus.OK);

        } else {

            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        }

    }
 
    

    @PutMapping("/accepted/{orderId}")

    //@PreAuthorize("hasAuthority('ADMIN')")

    public ResponseEntity<OrderDto> acceptedOrder(@PathVariable("orderId") int orderId)

    {

    	return orderService.acceptedOrder(orderId);

    }

    @PutMapping("/preparing/{orderId}")

    //@PreAuthorize("hasAuthority('ADMIN')")

    public ResponseEntity<OrderDto> preparingOrder(@PathVariable("orderId") int orderId)

    {

    	return orderService.preparingOrder(orderId);

    }

    @PutMapping("/delivered/{orderId}")

   // @PreAuthorize("hasAuthority('ADMIN')")

    public ResponseEntity<OrderDto> deliveredOrder(@PathVariable("orderId") int orderId)

    {

    	return orderService.deliveredOrder(orderId);

    }


    
    @DeleteMapping("/{orderId}")
    //@PreAuthorize("hasAuthority('USER')")
    public ResponseEntity<?> deleteOrder(@PathVariable int orderId) {
        try {
            boolean isDeleted = orderService.deleteOrder(orderId);
            return isDeleted ? new ResponseEntity<>("Deleted successfully",HttpStatus.OK) : ResponseEntity.notFound().build();
           // return new ResponseEntity<>("Deleted successfully",HttpStatus.OK);
        } catch (RuntimeException e) {
            // Return a proper HTTP 404 status if the order is not found
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
    }

}

