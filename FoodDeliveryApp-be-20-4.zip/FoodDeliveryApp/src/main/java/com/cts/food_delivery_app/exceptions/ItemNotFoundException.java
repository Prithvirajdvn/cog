package com.cts.food_delivery_app.exceptions;

public class ItemNotFoundException extends Exception {
  public ItemNotFoundException(String msg)
  {
	  super(msg);
  }
	
}
