package com.cts.food_delivery_app.repositories;


import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.food_delivery_app.entities.Delivery;


public interface DeliveryRepository extends JpaRepository<Delivery, Integer> {
	 List<Delivery> findByAgent_CustomerId(int agentId);

}
