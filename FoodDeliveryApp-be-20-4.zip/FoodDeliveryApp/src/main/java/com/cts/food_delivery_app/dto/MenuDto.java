package com.cts.food_delivery_app.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class MenuDto {
	
	private int itemId;
	
	@NotBlank(message="Menu name is required")
	private String name;
	
	@NotNull(message="Description cannot be null")
	@Size(min=5,max=100,message="Description can only contain 5-100 characters")
    private String description;
	
    private double price;
    
    private String imageUrl;
    
    @NotNull(message="restaurantId is required")
	private int restaurantId;	
}
