package com.cts.food_delivery_app.serviceImpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cts.food_delivery_app.dto.RestaurantDto;
import com.cts.food_delivery_app.entities.Menu;
import com.cts.food_delivery_app.entities.Restaurant;
import com.cts.food_delivery_app.exceptions.RestaurantNotFoundException;
import com.cts.food_delivery_app.repositories.RestaurantRepository;
import com.cts.food_delivery_app.service.RestaurantService;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class RestaurantServiceImpl implements RestaurantService {
    @Autowired
    private RestaurantRepository restaurantRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<RestaurantDto> getAllRestaurants() {
        List<Restaurant> restaurants = restaurantRepository.findAll();
        return restaurants.stream().map(restaurant -> modelMapper.map(restaurant, RestaurantDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public RestaurantDto getRestaurantById(int restaurantId) throws RestaurantNotFoundException {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant not found with ID: " + restaurantId));
        return modelMapper.map(restaurant, RestaurantDto.class);
    }

    @Override
    public List<RestaurantDto> getRestaurantByName(String name) throws RestaurantNotFoundException {
        List<Restaurant> restaurants = restaurantRepository.findByName(name);
        if (restaurants.isEmpty()) {
            throw new RestaurantNotFoundException("No restaurants found with name: " + name);
        }
        return restaurants.stream().map(restaurant -> modelMapper.map(restaurant, RestaurantDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public List<RestaurantDto> getRestaurantByCuisineType(String cuisineType) throws RestaurantNotFoundException {
        List<Restaurant> restaurants = restaurantRepository.findByCuisineType(cuisineType);
        if (restaurants.isEmpty()) {
            throw new RestaurantNotFoundException("No restaurants found with cuisine type: " + cuisineType);
        }
        return restaurants.stream().map(restaurant -> modelMapper.map(restaurant, RestaurantDto.class))
                .collect(Collectors.toList());
    }

    @Override
    public RestaurantDto createRestaurant(RestaurantDto restaurantDto) {
        Restaurant restaurant = modelMapper.map(restaurantDto, Restaurant.class);
        Restaurant savedRestaurant = restaurantRepository.save(restaurant);
        return modelMapper.map(savedRestaurant, RestaurantDto.class);
    }

    @Override
    public RestaurantDto updateRestaurant(int restaurantId, RestaurantDto restaurantDto) throws RestaurantNotFoundException {
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant not found with ID: " + restaurantId));
        
        restaurant.setName(restaurantDto.getName());
        restaurant.setLocation(restaurantDto.getLocation());
        restaurant.setCuisineType(restaurantDto.getCuisineType());
        restaurant.setRating(restaurantDto.getRating());

        // Map ItemPayload to Item
        /*List<Menu> menuItems = restaurantDto.getMenuItems().stream()
                .map(itemPayload -> modelMapper.map(itemPayload, Menu.class))
                .collect(Collectors.toList());
        
        restaurant.setMenuItems(menuItems);*/

        Restaurant updatedRestaurant = restaurantRepository.save(restaurant);
        return modelMapper.map(updatedRestaurant, RestaurantDto.class);
    }

    @Override
    public void deleteRestaurant(int restaurantId) throws RestaurantNotFoundException {
        if (!restaurantRepository.existsById(restaurantId)) {
            throw new RestaurantNotFoundException("Restaurant not found with ID: " + restaurantId);
        }
        restaurantRepository.deleteById(restaurantId);
    }


	
    
    
   
}
