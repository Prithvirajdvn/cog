package com.cts.food_delivery_app.exceptions;
 
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.http.HttpStatus;
 
@ResponseStatus(HttpStatus.NOT_FOUND)
 
public class IdNotFoundException extends RuntimeException {
	String msg;
    public IdNotFoundException(String msg) {
        super(msg);
    }
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}


}