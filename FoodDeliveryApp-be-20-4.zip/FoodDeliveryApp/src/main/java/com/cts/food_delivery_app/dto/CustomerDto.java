package com.cts.food_delivery_app.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import com.cts.food_delivery_app.enums.CustomerRole;
import com.fasterxml.jackson.annotation.JsonInclude;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerDto {
	
	private int customerId;
	
	@NotNull(message="customer role is required")
	private CustomerRole role; 
	
	@NotBlank(message="Name is required")
	private String name;
	
	@Email(message="Email is invalid")
	@NotBlank(message="Email is required")
	private String email;
	
	@NotNull(message = "Password is required")
    @Pattern(regexp = "^(?=.*[A-Za-z])(?=.*\\d)(?=.*[@#$%^&+=!])[A-Za-z\\d@#$%^&+=!]{8,20}$",
    		 message = "Password must be 8-20 characters long and include at least one letter, one number, and one special character")
	@JsonInclude(JsonInclude.Include.NON_NULL) 
	private String password; 
 
    @NotNull(message = "Phone number is required")
    @Pattern(regexp = "\\d{10}", message = "Phone number is invalid")
    private String phone;
    
	@Size(min=10,max=50,message="Address can only contain 10-50 characters")
    private String address;



}
