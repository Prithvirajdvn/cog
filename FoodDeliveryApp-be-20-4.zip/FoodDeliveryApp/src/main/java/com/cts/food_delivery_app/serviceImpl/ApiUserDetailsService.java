package com.cts.food_delivery_app.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.repositories.CustomerRepository;

@Service
public class ApiUserDetailsService implements UserDetailsService{
 
    @Autowired
    private CustomerRepository customerRepo;
 
    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        Customer customer = customerRepo.findByEmail(email).orElse(null);
 
        if(customer == null){
            throw new UsernameNotFoundException("No user found with email: " + email);
        }
 
        return new ApiUserDetails(customer);
    }
}