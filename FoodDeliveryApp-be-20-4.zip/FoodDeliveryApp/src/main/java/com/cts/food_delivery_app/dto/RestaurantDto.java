package com.cts.food_delivery_app.dto;


import java.util.List;
import com.cts.food_delivery_app.entities.Menu;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RestaurantDto {
	
    private int restaurantId;
    
	@NotBlank(message="Menu name is required")
    private String name;
	
	private String imageUrl;
	
	@NotBlank(message="location is required")
    private String location;
	
	@NotNull(message="CuisineType cannot be null")
	@Size(min=5,max=20,message="Cuisine Type can only contain 5-20 characters")
    private String cuisineType;
	
    private double rating;
    
    //@NotNull(message = "Menu items must not be null")
    //@Size(min = 1, message = "At least one menu item is required")
   // private List<Menu> menuItems;


}
