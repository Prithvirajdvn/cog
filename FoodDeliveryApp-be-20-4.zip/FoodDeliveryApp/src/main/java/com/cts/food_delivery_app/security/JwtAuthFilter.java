package com.cts.food_delivery_app.security;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
 
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.filter.OncePerRequestFilter;

import com.cts.food_delivery_app.serviceImpl.ApiUserDetailsService;
 
@Component
@Slf4j
public class JwtAuthFilter extends OncePerRequestFilter {
 
    //extract username and validating tokens
	
    private final JwtUtils jwtUtils;
 
    //to load customeruserdetailsservice class
	
    private final  ApiUserDetailsService apiUserDetailsService;
    
    
	
	@Autowired
    public JwtAuthFilter(JwtUtils jwtUtils,ApiUserDetailsService apiUserDetailsService) {
        this.jwtUtils = jwtUtils;
        this.apiUserDetailsService = apiUserDetailsService;
    }
 
    //to process request and apply filter logic(token validation)
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
 
        String token = getTokenFromRequest(request);
 
        if (token != null){
            String username = jwtUtils.getUsernameFromToken(token);
 
            UserDetails userDetails = apiUserDetailsService.loadUserByUsername(username);
 
            //username not empty check
            if (StringUtils.hasText(username) && jwtUtils.isTokenValid(token, userDetails)){
                log.info("VALID JWT FOR {}", username);
 
                //validate token and generate authentication token
                UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                        userDetails, null, userDetails.getAuthorities()
                );
                //given req is authenticated
                authenticationToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                //sets the authentication token in container
                SecurityContextHolder.getContext().setAuthentication(authenticationToken);
            }
 
        }
        //not authenticated request-token null
        //passes the req and response to next filter in the chain
        filterChain.doFilter(request, response);
    }
 
    //extracts the jwt from authorization header
    //to ensure properly formatted bearer token are processed
    private String getTokenFromRequest(HttpServletRequest request){
        //fetches value of authorization header from incoming HTTP request
        String token = request.getHeader("Authorization");
        if (StringUtils.hasText(token) && StringUtils.startsWithIgnoreCase(token, "Bearer ")){
            return token.substring(7);
        }
        return null;
    }
}