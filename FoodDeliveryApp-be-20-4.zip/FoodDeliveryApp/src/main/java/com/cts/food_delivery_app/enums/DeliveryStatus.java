package com.cts.food_delivery_app.enums;

public enum DeliveryStatus {
 INPROGRESS,DELIVERED
}
