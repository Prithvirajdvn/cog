package com.cts.food_delivery_app.serviceImpl;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.modelmapper.ModelMapper;
import com.cts.food_delivery_app.dto.MenuDto;
import com.cts.food_delivery_app.entities.Menu;
import com.cts.food_delivery_app.entities.Restaurant;
import com.cts.food_delivery_app.exceptions.ItemNotFoundException;
import com.cts.food_delivery_app.exceptions.RestaurantNotFoundException;
import com.cts.food_delivery_app.repositories.MenuRepository;
import com.cts.food_delivery_app.repositories.RestaurantRepository;
import com.cts.food_delivery_app.service.MenuService;

import jakarta.transaction.Transactional;

@Service
class MenuServiceImpl implements MenuService
{
	@Autowired
	private RestaurantRepository restaurantRepository;
	
	@Autowired
	private MenuRepository menuRepository;
 
	@Autowired
	private ModelMapper modelMapper;
	
	private boolean restaurantExists(Integer restaurantId) {
        return restaurantRepository.existsById(restaurantId);
    }
	@Override
	public List<MenuDto> getAllItems() {
		List<Menu> items = menuRepository.findAll();
		return items.stream().map(item -> modelMapper.map(item, MenuDto.class)).collect(Collectors.toList());
	}
 
	@Override
	public MenuDto getMenuById(int itemId) {
		Menu item = menuRepository.findById(itemId).orElse(null);
		if (item != null) {
			return modelMapper.map(item, MenuDto.class);
		}
		return null;
	}

	public Menu createMenu(String name, String description, double price, int restaurantId, MultipartFile file)
            throws RestaurantNotFoundException, IOException {
 
        // Validate restaurantId
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant ID " + restaurantId + " not found."));
 
        // Define an external directory for file uploads
        String uploadDirectory = "C:\\Users\\2389442\\Downloads\\FDA-fe\\fda-fe\\fda-fe\\fda-fe\\public\\assets\\images"; // Use an absolute external path
        File directory = new File(uploadDirectory);
 
        if (!directory.exists()) {
            boolean isCreated = directory.mkdirs();
            System.out.println("Directory created: " + isCreated);
        }
 
        // Save the file
        String fileName = file.getOriginalFilename();
        File destinationFile = new File(directory, fileName);
 
        try {
            file.transferTo(destinationFile);
            System.out.println("File saved to: " + destinationFile.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Failed to save file: " + e.getMessage());
            throw e;
        }
 
        // Build and save the Menu entity
        Menu menu = new Menu();
        menu.setName(name);
        menu.setDescription(description);
        menu.setPrice(price);
        menu.setImageUrl("assets/images/" + fileName); // Relative path for serving the file
        menu.setRestaurant(restaurant);
 
        return menuRepository.save(menu);
    }
 
@Override
    public Menu updateMenuItem(Integer restaurantId, String name, String description, double price, MultipartFile file)
            throws RestaurantNotFoundException, ItemNotFoundException, IOException {
 
        // Validate restaurantId
        Restaurant restaurant = restaurantRepository.findById(restaurantId)
                .orElseThrow(() -> new RestaurantNotFoundException("Restaurant ID " + restaurantId + " not found."));
 
        // Validate the menu item existence
        Menu menuItem = menuRepository.findByRestaurant_RestaurantIdAndName(restaurantId, name)
                .orElseThrow(() -> new ItemNotFoundException("Menu item with name '" + name + "' not found"));
 
        // Define an external directory for file uploads
        String uploadDirectory = "C:/Users/2389442/Downloads/FDA-fe/fda-fe/fda-fe/fda-fe/public/assets/images";
        File directory = new File(uploadDirectory);
 
        if (!directory.exists()) {
            boolean isCreated = directory.mkdirs();
            System.out.println("Directory created: " + isCreated);
        }
 
        // Save the file
        String fileName = file.getOriginalFilename();
        File destinationFile = new File(directory, fileName);
 
        try {
            file.transferTo(destinationFile);
            System.out.println("File saved to: " + destinationFile.getAbsolutePath());
        } catch (IOException e) {
            System.err.println("Failed to save file: " + e.getMessage());
            throw new RuntimeException("File upload failed: " + e.getMessage()); // Handle the exception locally
        }
 
        // Build and save the Menu entity
        menuItem.setName(name);
        menuItem.setDescription(description);
        menuItem.setPrice(price);
        menuItem.setImageUrl("assets/images/" + fileName); // Relative path for serving the file
        menuItem.setRestaurant(restaurant);
 
        return menuRepository.save(menuItem);
    }
 
	@Transactional
	public String deleteItem(Integer restaurantId, String name) throws ItemNotFoundException, RestaurantNotFoundException {
	    // Step 1: Check if the restaurant exists
	    boolean restaurantExists = restaurantRepository.existsById(restaurantId);
	    if (!restaurantExists) {
	        throw new RestaurantNotFoundException("Restaurant with ID " + restaurantId + " does not exist.");
	    }
 
	    // Step 2: Check if the item exists for the given restaurant
	    boolean itemExists = menuRepository.existsByRestaurantRestaurantIdAndName(restaurantId, name);
	    if (!itemExists) {
	        throw new ItemNotFoundException("Item with name '" + name + "' does not exist for restaurant ID " + restaurantId);
	    }
 
	    // Step 3: Proceed to delete the item
	    menuRepository.deleteByRestaurantRestaurantIdAndName(restaurantId, name);
		return "Deleted menu item successfully";
	}
	
	
 
	public List<MenuDto> getAllItemsByRestaurant(Integer restaurantId) throws RestaurantNotFoundException {
	    if (!restaurantRepository.existsById(restaurantId)) {
	        throw new RestaurantNotFoundException("Restaurant with ID " + restaurantId + " does not exist.");
	    }
 
	    List<Menu> items = menuRepository.findByRestaurant_RestaurantId(restaurantId);
 
	    return items.stream()
	                .map(item -> modelMapper.map(item, MenuDto.class))
	                .collect(Collectors.toList());
	}
 

 
}
 