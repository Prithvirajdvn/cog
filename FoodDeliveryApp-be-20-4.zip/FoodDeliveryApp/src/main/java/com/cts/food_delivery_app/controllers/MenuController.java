package com.cts.food_delivery_app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import com.cts.food_delivery_app.dto.MenuDto;
import com.cts.food_delivery_app.entities.Menu;
import com.cts.food_delivery_app.exceptions.ItemNotFoundException;
import com.cts.food_delivery_app.exceptions.RestaurantNotFoundException;
import com.cts.food_delivery_app.service.MenuService;
import com.cts.food_delivery_app.service.RestaurantService;

import java.util.Collections;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/menu")
public class MenuController {
    @Autowired
    private MenuService menuService;

   
    
    //The below post mapping code adds more than 1 item at a time
    
    @PostMapping("/create")
     //@PreAuthorize("hasAuthority('ADMIN')")
     public ResponseEntity<?> createMenu(
             @RequestParam("name") String name,
             @RequestParam("description") String description,
             @RequestParam("price") double price,
             @RequestParam("restaurantId") int restaurantId,
             @RequestParam("file") MultipartFile file) {
         try {
             Menu createdMenu = menuService.createMenu(name, description, price, restaurantId, file);
             return new ResponseEntity<>(createdMenu, HttpStatus.CREATED);
         } catch (RestaurantNotFoundException e) {
             return new ResponseEntity<>("Restaurant ID Not Found", HttpStatus.NOT_FOUND);
         } catch (Exception e) {
             return new ResponseEntity<>("Failed to create menu", HttpStatus.INTERNAL_SERVER_ERROR);
         }
         
         
     }
    
    @PutMapping("/{restaurantId}/{itemName}")
    //@PreAuthorize("hasAuthority('ADMIN')")
   public ResponseEntity<?> updateMenuItem(
           @PathVariable Integer restaurantId,
           @PathVariable String itemName,
           @RequestParam("name") String name,
           @RequestParam("description") String description,
           @RequestParam("price") double price,
           @RequestParam("restaurantId") Integer updatedRestaurantId,
           @RequestParam("file") MultipartFile file) {
       try {

           // Call service
           Menu updatedItem = null;
			try {
				updatedItem = menuService.updateMenuItem(restaurantId,name, description, price, file);
			} catch (java.io.IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

           return new ResponseEntity<>(updatedItem, HttpStatus.OK);
       } catch (RestaurantNotFoundException e) {
           return new ResponseEntity<>("Restaurant ID Not Found", HttpStatus.NOT_FOUND);
       } catch (ItemNotFoundException e) {
   		return new ResponseEntity<>("Item Name Not Found", HttpStatus.NOT_FOUND);
	  }
    }
    @DeleteMapping("/{restaurantId}/{menuName}")
    //@PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<String> deleteItem(
            @PathVariable Integer restaurantId,
            @PathVariable String menuName) {
        try {
        	
            menuService.deleteItem(restaurantId, menuName);
            return new ResponseEntity<>("Item deleted successfully.", HttpStatus.OK);
        } catch (RestaurantNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (ItemNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
        } catch (Exception e) {
            return new ResponseEntity<>("An error occurred: " + e.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{restaurantId}")
    public ResponseEntity<List<MenuDto>> getAllItemsByRestaurant(@PathVariable Integer restaurantId) {
        try {
            List<MenuDto> items = menuService.getAllItemsByRestaurant(restaurantId);
            return new ResponseEntity<>(items, HttpStatus.OK);
        } catch (RestaurantNotFoundException e) {
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
        }
    }
}


