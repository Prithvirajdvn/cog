package com.cts.food_delivery_app.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class RestaurantNotFoundException extends Exception {
	
	  public RestaurantNotFoundException(String msg)
	  {
		  super(msg);
	  }
}
