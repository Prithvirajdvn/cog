package com.cts.food_delivery_app.serviceImpl;
import java.util.List;
import java.util.stream.Collectors;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.cts.food_delivery_app.dto.MenuDto;
import com.cts.food_delivery_app.dto.OrderDto;
import com.cts.food_delivery_app.entities.Order;
import com.cts.food_delivery_app.enums.OrderStatus;
import com.cts.food_delivery_app.repositories.OrderRepository;
import com.cts.food_delivery_app.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Override
    public List<OrderDto> getAllOrders(int customerId) {
        List<Order> orders = orderRepository.findByCustomer_CustomerId(customerId);
        return orders.stream()
                .map(order -> modelMapper.map(order, OrderDto.class))
                .collect(Collectors.toList());
    }
    @Override
    public OrderDto getOrderById(int orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        return modelMapper.map(order, OrderDto.class);
    }
    @Override
    public OrderDto createOrder(OrderDto orderDto) {
        Order order = modelMapper.map(orderDto, Order.class);
        Order savedOrder = orderRepository.save(order);
        return modelMapper.map(savedOrder, OrderDto.class);
    }
    @Override
    public boolean deleteOrder(int orderId) {
        if (!orderRepository.existsById(orderId)) {
            throw new RuntimeException("Order not found with ID: " + orderId);
        }
        orderRepository.deleteById(orderId);
        return true;
    }
    @Override
    public ResponseEntity<OrderDto> pendingOrder(int orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        order.setStatus(OrderStatus.PENDING);
        orderRepository.save(order);
        return ResponseEntity.ok(modelMapper.map(order, OrderDto.class));
    }
    @Override
    public ResponseEntity<OrderDto> acceptedOrder(int orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        order.setStatus(OrderStatus.ACCEPTED);
        orderRepository.save(order);
        return ResponseEntity.ok(modelMapper.map(order, OrderDto.class));
    }
    @Override
    public ResponseEntity<OrderDto> preparingOrder(int orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        order.setStatus(OrderStatus.PREPARING);
        orderRepository.save(order);
        return ResponseEntity.ok(modelMapper.map(order, OrderDto.class));
    }
    @Override
    public ResponseEntity<OrderDto> deliveredOrder(int orderId) {
        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + orderId));
        order.setStatus(OrderStatus.DELIVERED);
        orderRepository.save(order);
        return ResponseEntity.ok(modelMapper.map(order, OrderDto.class));
    }
}
