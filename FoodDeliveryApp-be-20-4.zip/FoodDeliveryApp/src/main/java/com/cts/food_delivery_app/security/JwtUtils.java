package com.cts.food_delivery_app.security;


import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import jakarta.annotation.PostConstruct;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;
 
import com.cts.food_delivery_app.entities.Customer;
 
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.function.Function;
 
//business logic for jwt handling
@Service
@Slf4j
public class JwtUtils {
 
 
    private static final long EXPIRATION_TIME_IN_MILLISEC = 1000L * 60L *60L *24L * 30L * 6L; //Expires 6 months
    //signing and verifying jwt
    private SecretKey key;
 
    @Value("${secretJwtString}")    //Value in the application properties of 32characters
    private String secreteJwtString;
 
    //secret key converts to byte and then generates key
    //@Postconstruct-after beans are created and dependency injection init() method call
    @PostConstruct
    private void init(){
        byte[] keyBytes = secreteJwtString.getBytes(StandardCharsets.UTF_8);    
        this.key = new SecretKeySpec(keyBytes, "HmacSHA256");
    }
 
    public String generateToken(Customer user){
        String username = user.getEmail();
        return generateToken(username);
    }
 
    public String generateToken(String username){
        return Jwts.builder()
                .subject(username)
                .issuedAt(new Date(System.currentTimeMillis()))
                .expiration(new Date(System.currentTimeMillis() + EXPIRATION_TIME_IN_MILLISEC))
                .signWith(key) //signature-HMAC-SHA256 ALGORITHM SECRET KEY
                .compact(); //returns the generated jwt as string
    }
 
    //subject-payload returns tokens and payload of tokenclaims(user)
    public String getUsernameFromToken(String token){
        return extractClaims(token, Claims::getSubject);
    }
 
    //generic method to extract claim from token
    private <T> T extractClaims(String token, Function<Claims, T> claimsTFunction){
        //parese token verify with secret key based on token extract claims
        return claimsTFunction.apply(Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload());
    }
 
    public boolean isTokenValid(String token, UserDetails userDetails){
        final String username = getUsernameFromToken(token);
        return (username.equals(userDetails.getUsername()) && !isTokenExpired(token));
    }
 
    //checks token us expired or not
    private boolean isTokenExpired(String token){
        //takes token exp date and check with current date that before exp date
        return extractClaims(token, Claims::getExpiration).before(new Date());
    }
}
 