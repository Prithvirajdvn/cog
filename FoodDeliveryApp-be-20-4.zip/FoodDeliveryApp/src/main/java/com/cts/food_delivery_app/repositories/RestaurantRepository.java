package com.cts.food_delivery_app.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.food_delivery_app.entities.Restaurant;

public interface RestaurantRepository extends JpaRepository<Restaurant, Integer> {

	List<Restaurant> findByCuisineType(String cuisineType);
    boolean existsById(Integer restaurantId);
	List<Restaurant> findByName(String name);

}
