package com.cts.food_delivery_app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.food_delivery_app.dto.CustomerDto;
import com.cts.food_delivery_app.dto.CustomerLoginDto;
import com.cts.food_delivery_app.dto.JwtDto;
import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.service.CustomerService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/auth")
public class AuthController {
	@Autowired
    private CustomerService customerService;


    @PostMapping("/register")
    public ResponseEntity<Customer> createCustomer(@RequestBody CustomerDto customerDto) {
    	ResponseEntity<Customer> createdCustomer= customerService.createCustomer(customerDto);
        return createdCustomer;
    }
    
    @PostMapping("/login")
    public ResponseEntity<JwtDto> loginUser(@RequestBody @Valid CustomerLoginDto dto) {
        return customerService.checkLogin(dto);
    }

}
