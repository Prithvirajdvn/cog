package com.cts.food_delivery_app.dto;
 
import jakarta.validation.constraints.Email;

import jakarta.validation.constraints.NotBlank;

import jakarta.validation.constraints.NotNull;

import jakarta.validation.constraints.Pattern;

import lombok.AllArgsConstructor;

import lombok.Data;
import lombok.NoArgsConstructor;
 
@Data
@AllArgsConstructor
@NoArgsConstructor
public class CustomerLoginDto {

	@Email(message="Email is invalid")
	@NotBlank(message="Email is required")
	private String email;

	@NotNull(message = "Password is required")
    private String password;
 
}

 