package com.cts.food_delivery_app.dto;



import java.util.List;
import com.cts.food_delivery_app.enums.OrderStatus;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotNull;

import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.entities.Restaurant;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class OrderDto {
	
	@NotNull(message="orderId is required")
	private int orderId;
	
	@NotNull(message="customerId is required")
	private int customerId;
	
	@NotNull(message="restaurantId is required")
	private int restaurantId;
	
	private OrderStatus status;
	
	private double totalAmount;
	
	//@NotNull(message="items are required")
	private List<ItemsOrderedDto> menuItems;
	
	
}
