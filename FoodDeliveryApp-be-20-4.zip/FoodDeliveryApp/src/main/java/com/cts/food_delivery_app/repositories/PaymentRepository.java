package com.cts.food_delivery_app.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cts.food_delivery_app.entities.Payment;

public interface PaymentRepository extends JpaRepository<Payment, Integer> {

}
