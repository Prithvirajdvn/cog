package com.cts.food_delivery_app.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.cts.food_delivery_app.dto.MenuDto;
import com.cts.food_delivery_app.entities.Menu;
import com.cts.food_delivery_app.exceptions.ItemNotFoundException;
import com.cts.food_delivery_app.exceptions.RestaurantNotFoundException;

public interface MenuService {
	
	List<MenuDto> getAllItems();
    //MenuDto getItemById(int itemId);
	Menu updateMenuItem(Integer restaurantId, String name, String description,double price,MultipartFile file) throws RestaurantNotFoundException, ItemNotFoundException,IOException;
    Menu createMenu(String name, String description, double price, int restaurantId, MultipartFile file) throws RestaurantNotFoundException, IOException;
    String deleteItem(Integer restaurantId, String name) throws RestaurantNotFoundException, ItemNotFoundException;
    List<MenuDto> getAllItemsByRestaurant(Integer restaurantId) throws RestaurantNotFoundException;
	MenuDto getMenuById(int itemId);
	//Menu createMenu(String name, String description, double price, int restaurantId, MultipartFile file);

}
