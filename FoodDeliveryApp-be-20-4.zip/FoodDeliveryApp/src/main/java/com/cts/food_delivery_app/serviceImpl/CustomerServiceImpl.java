package com.cts.food_delivery_app.serviceImpl;

import java.util.List;
import java.util.Optional;

import com.cts.food_delivery_app.dto.CustomerDto;
import com.cts.food_delivery_app.dto.CustomerLoginDto;
import com.cts.food_delivery_app.dto.JwtDto;
import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.enums.CustomerRole;
import com.cts.food_delivery_app.exceptions.ApiException;
import com.cts.food_delivery_app.exceptions.IdNotFoundException;
import com.cts.food_delivery_app.repositories.CustomerRepository;
import com.cts.food_delivery_app.security.JwtUtils;
import com.cts.food_delivery_app.service.CustomerService;

import jakarta.transaction.Transactional;
import jakarta.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private JwtUtils jwtUtils;

    @Autowired
    private AuthenticationManager authManager;

    @Override
    public List<Customer> getAllCustomers() {
        List<Customer> customers = customerRepository.findAll();
        if (customers.isEmpty()) {
            throw new ApiException("No users found", HttpStatus.NOT_FOUND);
        }
        return customers;
    }

    @Override
    public Customer getCustomerById(int customerId) {
    	 Customer user = customerRepository.findById(customerId).orElse(null);
         if (user == null) {
             throw new ApiException("No user with user id: " + customerId + " found", HttpStatus.BAD_REQUEST);
         }
         return (user);
    }
  
    @Transactional
    @Override
    public ResponseEntity<Customer> createCustomer(CustomerDto customerDto) {
       
    	 if(customerRepository.findByEmail(customerDto.getEmail()).orElse(null) != null){
             throw new ApiException("Email id already registered", HttpStatus.BAD_REQUEST);
         }


        if(customerDto.getRole() != CustomerRole.USER && customerDto.getRole() != CustomerRole.ADMIN
        		&& customerDto.getRole() != CustomerRole.AGENT){
            throw new ApiException("Invalid user role: " + customerDto.getRole(), HttpStatus.BAD_REQUEST);
        }

         Customer user = new Customer();        
        
        user.setCustomerId(customerDto.getCustomerId());
        user.setName(customerDto.getName());
        user.setEmail(customerDto.getEmail());
        user.setRole(customerDto.getRole());
        // Encode password before storing
        user.setPassword(passwordEncoder.encode(customerDto.getPassword()));
        user.setPhone(customerDto.getPhone());
        user.setAddress(customerDto.getAddress());

        Customer savedUser = customerRepository.save(user);
        if (savedUser == null) {
            throw new ApiException("Failed to create new user", HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return ResponseEntity.status(HttpStatus.CREATED).body(savedUser);
    }

    @Transactional
    @Override
	public ResponseEntity<Customer> deleteCustomer(int customerId) {
    		
    	 Customer user = customerRepository.findById(customerId).orElse(null);
         if (user == null) {
             throw new ApiException("No user with user id: " + customerId + " found", HttpStatus.BAD_REQUEST);
         }
	    customerRepository.deleteById(customerId);
	    return ResponseEntity.status(HttpStatus.OK).body(user);
	}

    @Override
    public ResponseEntity<JwtDto> checkLogin(@Valid CustomerLoginDto dto) {
        // Authenticate user credentials
        Authentication auth = authManager.authenticate(
                new UsernamePasswordAuthenticationToken(dto.getEmail(), dto.getPassword()));

        Customer customer = customerRepository.findByEmail(dto.getEmail())
                .orElseThrow(() -> new ApiException("No user found with email: " + dto.getEmail(), HttpStatus.UNAUTHORIZED));

        if (auth.isAuthenticated()) {
            String jwt = jwtUtils.generateToken(dto.getEmail());

            JwtDto jwtDto = new JwtDto();
            jwtDto.setEmail(dto.getEmail());
            jwtDto.setCustomerId(customer.getCustomerId());
            jwtDto.setJwtToken(jwt);

            return ResponseEntity.status(HttpStatus.OK).body(jwtDto);
        }

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
    }

    @Transactional
    public ResponseEntity<Customer> changeUserDetails(CustomerDto dto) {
        int customerId = dto.getCustomerId();

        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new ApiException("No user found with id: " + customerId, HttpStatus.BAD_REQUEST));

        customer.setName(dto.getName());
        customer.setEmail(dto.getEmail());
        // Encode password before updating
        customer.setPassword(passwordEncoder.encode(dto.getPassword()));
        customer.setPhone(dto.getPhone());
        customer.setAddress(dto.getAddress());

        customerRepository.save(customer);
        return ResponseEntity.status(HttpStatus.OK).body(customer);
    }
    
    public String getRoleByEmail(String email) {
        return customerRepository.findRoleByEmail(email);
    }

    @Override
    public CustomerDto getCustomerByEmail(String email) throws IdNotFoundException {
        Optional<Customer> customerOpt = customerRepository.findByEmail(email);

        if (customerOpt.isPresent()) {
            Customer customer = customerOpt.get();
            return new CustomerDto(
                customer.getCustomerId(),
                customer.getRole(),
                 customer.getName(),
                customer.getEmail(),
                customer.getPassword(),
                customer.getPhone(),
                customer.getAddress()
            );
        } else {
            throw new IdNotFoundException("Customer not found with email: " + email);
        }
    }

}
