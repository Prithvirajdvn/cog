package com.cts.food_delivery_app.service;

import java.util.List;
import com.cts.food_delivery_app.dto.RestaurantDto;
import com.cts.food_delivery_app.exceptions.RestaurantNotFoundException;

public interface RestaurantService {
	
    List<RestaurantDto> getAllRestaurants();

    RestaurantDto getRestaurantById(int restaurantId) throws RestaurantNotFoundException;

    List<RestaurantDto> getRestaurantByName(String name) throws RestaurantNotFoundException;

    List<RestaurantDto> getRestaurantByCuisineType(String cuisineType) throws RestaurantNotFoundException;

    RestaurantDto createRestaurant(RestaurantDto restaurantDto);

    RestaurantDto updateRestaurant(int restaurantId, RestaurantDto restaurantDto) throws RestaurantNotFoundException;

    void deleteRestaurant(int restaurantId) throws RestaurantNotFoundException;
    
}