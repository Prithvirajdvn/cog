package com.cts.food_delivery_app.enums;

public enum OrderStatus {
	PENDING,ACCEPTED,PREPARING,DELIVERED
}
