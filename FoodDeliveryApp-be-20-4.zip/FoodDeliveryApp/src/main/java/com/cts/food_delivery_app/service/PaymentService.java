package com.cts.food_delivery_app.service;

import java.util.List;

import com.cts.food_delivery_app.dto.PaymentDto;

public interface PaymentService {

	List<PaymentDto> getAllPayments();

	PaymentDto getPaymentById(int paymentId);

	PaymentDto createPayment(PaymentDto paymentDto);

	void deletePayment(int paymentId);
}
