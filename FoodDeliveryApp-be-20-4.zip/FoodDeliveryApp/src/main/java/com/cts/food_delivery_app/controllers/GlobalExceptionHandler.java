package com.cts.food_delivery_app.controllers;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.cts.food_delivery_app.exceptions.ApiException;
import com.cts.food_delivery_app.exceptions.DataIntegrityViolationException;
import com.cts.food_delivery_app.exceptions.IdNotFoundException;
import com.cts.food_delivery_app.exceptions.ItemNotFoundException;
import com.cts.food_delivery_app.exceptions.RestaurantNotFoundException;

@ControllerAdvice
public class GlobalExceptionHandler {
 
	@ExceptionHandler(IdNotFoundException.class)
	@ResponseStatus(code=HttpStatus.NOT_FOUND)
	
	public  ResponseEntity<String> IdNotFoundExceptionHandler(IdNotFoundException e)
	{
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(e.getMsg());	
	}
	
	@ExceptionHandler(ItemNotFoundException.class)
	@ResponseStatus(code=HttpStatus.NOT_FOUND)
	public String ItemNotFoundExceptionHandler(IdNotFoundException e)
	{
		return e.getMessage();
		
	}
	
	@ExceptionHandler(RestaurantNotFoundException.class)
	@ResponseStatus(code=HttpStatus.NOT_FOUND)
	public String RestaurantNotFoundExceptionHandler(RestaurantNotFoundException e)
	{
		return e.getMessage();
		
	}
	
	@ExceptionHandler(ApiException.class)
	@ResponseStatus(code=HttpStatus.NOT_FOUND)
    public String handleApiException(ApiException e) {
		return e.getMessage();   
	}
	
	@ExceptionHandler(DataIntegrityViolationException.class)
	@ResponseStatus(HttpStatus.CONFLICT)
	public ResponseEntity<String> handleDataIntegrityViolationException(DataIntegrityViolationException e) {
	    return ResponseEntity.status(HttpStatus.CONFLICT).body(e.getMessage());
	}
	
	@ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, String>> handleGeneralException(Exception ex){
 
        Map<String, String> err = new HashMap<>();
       
        err.put("error", ex.getClass().getSimpleName());
        err.put("message", ex.getMessage());
        err.put("statusCode", HttpStatus.INTERNAL_SERVER_ERROR.toString());
 
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(err);
    } 

 
}
