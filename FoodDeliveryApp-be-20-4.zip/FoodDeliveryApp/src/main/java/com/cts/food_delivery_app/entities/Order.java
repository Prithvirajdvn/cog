package com.cts.food_delivery_app.entities;

 
import java.util.List;
 
import com.cts.food_delivery_app.dto.ItemsOrderedDto;

import com.cts.food_delivery_app.enums.DeliveryStatus;

import com.cts.food_delivery_app.enums.OrderStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;

import jakarta.persistence.Column;

import jakarta.persistence.Entity;

import jakarta.persistence.EnumType;

import jakarta.persistence.Enumerated;

import jakarta.persistence.GeneratedValue;

import jakarta.persistence.GenerationType;

import jakarta.persistence.Id;

import jakarta.persistence.JoinColumn;

import jakarta.persistence.ManyToOne;

import jakarta.persistence.OneToMany;

import jakarta.persistence.OneToOne;

import jakarta.persistence.Table;

import jakarta.persistence.Transient;

import lombok.AllArgsConstructor;

import lombok.Data;

import lombok.NoArgsConstructor;
 
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Orders")

public class Order 
{

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int orderId;
 
	@ManyToOne(cascade={CascadeType.MERGE})
	@JoinColumn(name = "customerId")
	private Customer customer;
 
	@ManyToOne(cascade={CascadeType.MERGE})
	@JoinColumn(name = "restaurantId")
	private Restaurant restaurant;

	@Enumerated(value=EnumType.STRING)
	@Column(name="status")
	private OrderStatus status;

	private double totalAmount;

	@OneToOne(mappedBy="order",cascade=CascadeType.ALL)
    @JsonIgnore
	private Delivery delivery;

	@OneToMany(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "order_id", referencedColumnName = "orderId")
    private List<Menu> menuItems;
	
	@OneToOne(mappedBy="order",cascade=CascadeType.ALL)
	@JsonIgnore
	private Payment payment;

	public void pending()
	{

		this.setStatus(status.PENDING);
	}

	public void accepted()
	{

		this.setStatus(status.ACCEPTED);
	}

	public void preparing()
	{

		this.setStatus(status.PREPARING);
	}

	public void delivered()
	{

		this.setStatus(status.DELIVERED);
	}


}

 
