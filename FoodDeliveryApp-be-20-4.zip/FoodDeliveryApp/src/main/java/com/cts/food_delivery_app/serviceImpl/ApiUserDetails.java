package com.cts.food_delivery_app.serviceImpl;

import java.util.Collection;
import java.util.List;
 
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.cts.food_delivery_app.entities.Customer;

public class ApiUserDetails implements UserDetails{
	 
    private final Customer customer;
 
    ApiUserDetails(Customer customer){
        this.customer = customer;
    }
 
    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return List.of(new SimpleGrantedAuthority(customer.getRole().name()));
    }
 
    @Override
    public String getPassword() {
        return customer.getPassword();
    }
 
    @Override
    public String getUsername() {
        return customer.getEmail();
    }
}