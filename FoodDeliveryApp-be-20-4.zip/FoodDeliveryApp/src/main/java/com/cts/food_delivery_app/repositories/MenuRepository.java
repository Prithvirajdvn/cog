package com.cts.food_delivery_app.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.food_delivery_app.entities.Menu;

public interface MenuRepository extends JpaRepository<Menu, Integer> {

	void deleteByRestaurantRestaurantIdAndName(Integer restaurantId, String name);

	Optional<Menu> findByRestaurant_RestaurantIdAndName(Integer restaurantId, String itemName);

	boolean existsByRestaurantRestaurantIdAndName(Integer restaurantId, String name);

	List<Menu> findByRestaurant_RestaurantId(Integer restaurantId);

	

}
