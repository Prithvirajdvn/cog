package com.cts.food_delivery_app.controllers;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.cts.food_delivery_app.dto.RestaurantDto;
import com.cts.food_delivery_app.exceptions.IdNotFoundException;
import com.cts.food_delivery_app.exceptions.RestaurantNotFoundException;
import com.cts.food_delivery_app.service.RestaurantService;

import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/restaurants")
public class RestaurantController {
	
    @Autowired
    private RestaurantService restaurantService;

    @GetMapping("/getAllRestaurants")
    public ResponseEntity<List<RestaurantDto>> getAllRestaurants() {
        List<RestaurantDto> restaurants = restaurantService.getAllRestaurants();
        return new ResponseEntity<>(restaurants, HttpStatus.OK);
    }

    @GetMapping("/getRestaurantById/{restaurantId}")
    public ResponseEntity<RestaurantDto> getRestaurantById(@PathVariable int restaurantId) throws RestaurantNotFoundException,IdNotFoundException {
        RestaurantDto restaurant = restaurantService.getRestaurantById(restaurantId);
        if (restaurant != null) {
            return new ResponseEntity<>(restaurant, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @GetMapping("/getRestaurantByCuisineType/{restaurantName}")
    public ResponseEntity<List<RestaurantDto>> getRestaurantByCuisineType(@PathVariable String restaurantName) throws RestaurantNotFoundException {
        List<RestaurantDto> restaurant = restaurantService.getRestaurantByCuisineType(restaurantName);
        if (restaurant != null) {
            return new ResponseEntity<>(restaurant, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @GetMapping("/getRestaurantByName/{restaurantName}")
    public ResponseEntity<List<RestaurantDto>> getRestaurantByName(@PathVariable String restaurantName) throws RestaurantNotFoundException {
        List<RestaurantDto> restaurant = restaurantService.getRestaurantByName(restaurantName);
        if (restaurant != null) {
            return new ResponseEntity<>(restaurant, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    
    @PostMapping("/createRestaurant")
    //@PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<RestaurantDto> createRestaurant(@RequestBody @Valid RestaurantDto restaurantPayload) {
        RestaurantDto createdRestaurant = restaurantService.createRestaurant(restaurantPayload);
        return new ResponseEntity<>(createdRestaurant, HttpStatus.CREATED);
    }
    
    @PutMapping("/updateRestaurant/{restaurantId}")
   // @PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<RestaurantDto> updateRestaurant(@PathVariable int restaurantId, @RequestBody @Valid RestaurantDto restaurantDto) throws RestaurantNotFoundException{
        RestaurantDto updatedRestaurant = restaurantService.updateRestaurant(restaurantId, restaurantDto);
        if (updatedRestaurant != null) {
            return new ResponseEntity<>(updatedRestaurant, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/deleteRestaurant/{restaurantId}")
    //@PreAuthorize("hasAuthority('ADMIN')")
    public ResponseEntity<Map<String, String>> deleteRestaurant(@PathVariable int restaurantId) {
        try {
            restaurantService.deleteRestaurant(restaurantId);
            
            // ✅ Return a proper JSON response
            Map<String, String> response = new HashMap<>();
            response.put("message", "Restaurant deleted successfully");
            
            return ResponseEntity.ok(response);
        } catch (RestaurantNotFoundException e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", "Restaurant not found with ID: " + restaurantId);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
        }
    }


    
}





