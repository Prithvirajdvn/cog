package com.cts.food_delivery_app.entities;

import java.util.Date;

import com.cts.food_delivery_app.enums.CustomerRole;
import com.cts.food_delivery_app.enums.DeliveryStatus;
import com.cts.food_delivery_app.enums.OrderStatus;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.Future;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "Delivery")
public class Delivery {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int deliveryId;

	@OneToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE,CascadeType.DETACH})
	@JoinColumn(name="orderId",referencedColumnName="orderId")
	@JsonIgnore
	private Order order;

	@ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE,CascadeType.DETACH})
	@JoinColumn(name="customerId")
	@NotNull(message="AgentId is required")
	private Customer agent;

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "estimatedDeliveryTime")
	@NotNull(message="arrival time cannot be null")
	@Future
	private Date estimatedTimeOfArrival;

	@Enumerated(value=EnumType.STRING)
	@Column(name="status")
	private DeliveryStatus status;
	
	public void inProgress()
	{
		this.setStatus(status.INPROGRESS);
	}
	public void delivered()
	{
		this.setStatus(status.DELIVERED);
	}
	
}
