package com.cts.food_delivery_app.dto;

import lombok.Data;

@Data
public class JwtDto {
	
	private int customerId;
	private String email;
	private String jwtToken;

}
