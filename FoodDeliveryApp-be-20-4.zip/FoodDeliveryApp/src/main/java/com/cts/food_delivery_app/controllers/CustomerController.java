package com.cts.food_delivery_app.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.cts.food_delivery_app.dto.CustomerDto;
import com.cts.food_delivery_app.dto.CustomerLoginDto;
import com.cts.food_delivery_app.dto.JwtDto;
import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.exceptions.IdNotFoundException;
import com.cts.food_delivery_app.service.CustomerService;

import jakarta.validation.Valid;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/customers")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    @DeleteMapping("/{customerId}")
    public ResponseEntity<String> deleteCustomer(@PathVariable int customerId) {
        customerService.deleteCustomer(customerId);
        return new ResponseEntity<>("Deleted successfully",HttpStatus.OK);
    }
    
    @GetMapping("/getAll")
    public ResponseEntity<List<Customer>> getAllCustomers() {
        List<Customer> customers =  customerService.getAllCustomers();
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    @GetMapping("/{customerId}")
    public ResponseEntity<Customer> getCustomerById(@PathVariable int customerId) {
    	Customer customer = customerService.getCustomerById(customerId);
        if (customer != null) {
            return new ResponseEntity<>(customer, HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
    
    @PutMapping("/update")
    public ResponseEntity<?> changeUserDetails(@RequestBody CustomerDto customerDto) {
        CustomerDto existingCustomer = customerService.getCustomerByEmail(customerDto.getEmail());

        if (customerDto.getPassword() == null || customerDto.getPassword().isEmpty()) {
            // ✅ Preserve existing hashed password
            customerDto.setPassword(existingCustomer.getPassword());
        }

        ResponseEntity<Customer> updatedCustomer = customerService.changeUserDetails(customerDto);
        return ResponseEntity.ok(updatedCustomer);
    }

    
    @GetMapping("/getRoleByEmail")
    public ResponseEntity<Map<String, String>> getRoleByEmail(@RequestParam String email) {
        String role = customerService.getRoleByEmail(email);
        if (role != null) {
            Map<String, String> response = new HashMap<>();
            response.put("role", role);
            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
        }
    }
   
    
    @GetMapping("/getCustomerByEmail")
    public ResponseEntity<CustomerDto> getCustomerByEmail(@RequestParam String email) throws IdNotFoundException {
        CustomerDto customer = customerService.getCustomerByEmail(email);
        if (customer == null) {
            throw new IdNotFoundException("Customer not found with email: " + email);
        }
        return ResponseEntity.ok(customer);
    }


}
