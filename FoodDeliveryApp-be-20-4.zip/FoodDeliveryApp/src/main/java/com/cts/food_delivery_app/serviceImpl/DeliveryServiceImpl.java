package com.cts.food_delivery_app.serviceImpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cts.food_delivery_app.dto.DeliveryDto;
import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.entities.Delivery;
import com.cts.food_delivery_app.entities.Order;
import com.cts.food_delivery_app.enums.DeliveryStatus;
import com.cts.food_delivery_app.repositories.CustomerRepository;
import com.cts.food_delivery_app.repositories.DeliveryRepository;
import com.cts.food_delivery_app.repositories.OrderRepository;
import com.cts.food_delivery_app.service.DeliveryService;

import jakarta.transaction.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DeliveryServiceImpl implements DeliveryService {
	
    @Autowired
    private DeliveryRepository deliveryRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private CustomerRepository customerRepository;
    @Autowired
    private ModelMapper modelMapper;

    @Override
    public List<DeliveryDto> getAllDeliveries(int agentId) {
        // Fetch all deliveries for the given agentId
        List<Delivery> deliveries = deliveryRepository.findByAgent_CustomerId(agentId);

        // Map Delivery entities to DeliveryDto objects
        return deliveries.stream()
                .map(delivery -> modelMapper.map(delivery, DeliveryDto.class))
                .collect(Collectors.toList());
    }

    public DeliveryDto getDeliveryById(int deliveryId) {
        Delivery delivery = deliveryRepository.findById(deliveryId).orElse(null);
        if (delivery != null) {
            return modelMapper.map(delivery, DeliveryDto.class);
        }
        return null;
    }

    public DeliveryDto createDelivery(DeliveryDto deliveryDto) {
    	 Delivery delivery = modelMapper.map(deliveryDto, Delivery.class);

         // Fetch the Order by orderId and set it
         Order order = orderRepository.findById(deliveryDto.getOrderId())
                 .orElseThrow(() -> new RuntimeException("Order not found with ID: " + deliveryDto.getOrderId()));
         delivery.setOrder(order);

         // Fetch the Customer (Agent) by agentId and set it
         Customer agent = customerRepository.findById(deliveryDto.getAgentId())
                 .orElseThrow(() -> new RuntimeException("Agent not found with ID: " + deliveryDto.getAgentId()));
         delivery.setAgent(agent);

         // Save the Delivery object
         Delivery savedDelivery = deliveryRepository.save(delivery);

         // Map back to DeliveryDto and return
         return modelMapper.map(savedDelivery, DeliveryDto.class);
    }
    @Transactional
    public String deleteDelivery(int deliveryId) {
        deliveryRepository.deleteById(deliveryId);
		return "Delivery deleted successfully";
    }
    
    @Override
    public ResponseEntity<DeliveryDto> inProgressOrder(int deliveryId) {
        Delivery delivery = deliveryRepository.findById(deliveryId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + deliveryId));
        delivery.setStatus(DeliveryStatus.INPROGRESS); // Update the status to INPROGRESS
        deliveryRepository.save(delivery);
        return ResponseEntity.ok(modelMapper.map(delivery, DeliveryDto.class));
    }

    @Override
    public ResponseEntity<DeliveryDto> deliveredOrder(int deliveryId) {
    	Delivery delivery = deliveryRepository.findById(deliveryId)
                .orElseThrow(() -> new RuntimeException("Order not found with ID: " + deliveryId));
        delivery.setStatus(DeliveryStatus.DELIVERED); // Update the status to DELIVERED
        deliveryRepository.save(delivery);
        return ResponseEntity.ok(modelMapper.map(delivery, DeliveryDto.class));
    }

}
