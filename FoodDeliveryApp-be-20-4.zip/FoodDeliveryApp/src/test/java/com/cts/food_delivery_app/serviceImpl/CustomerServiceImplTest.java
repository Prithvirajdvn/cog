package com.cts.food_delivery_app.serviceImpl;

import com.cts.food_delivery_app.dto.CustomerDto;
import com.cts.food_delivery_app.dto.CustomerLoginDto;
import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.enums.CustomerRole;
import com.cts.food_delivery_app.exceptions.ApiException;
import com.cts.food_delivery_app.repositories.CustomerRepository;
import com.cts.food_delivery_app.security.JwtUtils;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CustomerServiceImplTest {

    @Mock
    private CustomerRepository customerRepository;

    @Mock
    private PasswordEncoder passwordEncoder;

    @Mock
    private JwtUtils jwtUtils;

    @Mock
    private AuthenticationManager authManager;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testGetCustomerById_Success() {
        int customerId = 1;
        Customer mockCustomer = new Customer();
        mockCustomer.setCustomerId(customerId);
        mockCustomer.setName("John Doe");
        mockCustomer.setEmail("john.doe@example.com");

        when(customerRepository.findById(customerId)).thenReturn(Optional.of(mockCustomer));

        Customer result = customerService.getCustomerById(customerId);

        assertNotNull(result);
        assertEquals("John Doe", result.getName());
        verify(customerRepository, times(1)).findById(customerId);
    }

    @Test
    void testGetCustomerById_NotFound() {
        int customerId = 1;

        when(customerRepository.findById(customerId)).thenReturn(Optional.empty());

        ApiException exception = assertThrows(ApiException.class, () -> customerService.getCustomerById(customerId));

        assertEquals("No user with user id: " + customerId + " found", exception.getMessage());
        verify(customerRepository, times(1)).findById(customerId);
    }

    @Test
    void testDeleteCustomer_Success() {
        int customerId = 1;
        Customer mockCustomer = new Customer();
        mockCustomer.setCustomerId(customerId);

        when(customerRepository.findById(customerId)).thenReturn(Optional.of(mockCustomer));
        doNothing().when(customerRepository).deleteById(customerId);

        ResponseEntity<Customer> response = customerService.deleteCustomer(customerId);

        assertNotNull(response);
        assertEquals(mockCustomer, response.getBody());
        verify(customerRepository, times(1)).findById(customerId);
        verify(customerRepository, times(1)).deleteById(customerId);
    }

    @Test
    void testDeleteCustomer_NotFound() {
        int customerId = 1;

        when(customerRepository.findById(customerId)).thenReturn(Optional.empty());

        ApiException exception = assertThrows(ApiException.class, () -> customerService.deleteCustomer(customerId));

        assertEquals("No user with user id: " + customerId + " found", exception.getMessage());
        verify(customerRepository, times(1)).findById(customerId);
        verify(customerRepository, never()).deleteById(customerId);
    }

    @Test
    void testCreateCustomer_Success() {
        CustomerDto customerDto = new CustomerDto();
        customerDto.setCustomerId(1);
        customerDto.setName("John Doe");
        customerDto.setEmail("john.doe@example.com");
        customerDto.setPassword("password123");
        customerDto.setRole(CustomerRole.USER);

        Customer mockCustomer = new Customer();
        mockCustomer.setCustomerId(customerDto.getCustomerId());
        mockCustomer.setName(customerDto.getName());
        mockCustomer.setEmail(customerDto.getEmail());
        mockCustomer.setRole(customerDto.getRole());
        mockCustomer.setPassword("encodedPassword");

        when(customerRepository.findByEmail(customerDto.getEmail())).thenReturn(Optional.empty());
        when(passwordEncoder.encode(customerDto.getPassword())).thenReturn("encodedPassword");
        when(customerRepository.save(any(Customer.class))).thenReturn(mockCustomer);

        ResponseEntity<Customer> response = customerService.createCustomer(customerDto);

        assertNotNull(response);
        assertEquals(mockCustomer, response.getBody());
        verify(customerRepository, times(1)).findByEmail(customerDto.getEmail());
        verify(customerRepository, times(1)).save(any(Customer.class));
    }

    @Test
    void testCreateCustomer_EmailAlreadyRegistered() {
        CustomerDto customerDto = new CustomerDto();
        customerDto.setEmail("existing.email@example.com");

        when(customerRepository.findByEmail(customerDto.getEmail())).thenReturn(Optional.of(new Customer()));

        ApiException exception = assertThrows(ApiException.class, () -> customerService.createCustomer(customerDto));

        assertEquals("Email id already registered", exception.getMessage());
        verify(customerRepository, times(1)).findByEmail(customerDto.getEmail());
        verify(customerRepository, never()).save(any(Customer.class));
    }
}





/*package com.cts.food_delivery_app.serviceImpl;
 
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
 
import java.util.List;
import java.util.Optional;
 
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.modelmapper.ModelMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
 
import com.cts.food_delivery_app.dto.CustomerDto;
import com.cts.food_delivery_app.dto.CustomerLoginDto;
import com.cts.food_delivery_app.dto.JwtDto;
import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.enums.CustomerRole;
import com.cts.food_delivery_app.exceptions.ApiException;
import com.cts.food_delivery_app.exceptions.IdNotFoundException;
import com.cts.food_delivery_app.repositories.CustomerRepository;
import com.cts.food_delivery_app.security.JwtUtils;
 
@ExtendWith(MockitoExtension.class)
public class CustomerServiceImplTest {
 
    @Mock
    private CustomerRepository customerRepository;
 
    @Mock
    private ModelMapper modelMapper;
 
    @Mock
    private PasswordEncoder passwordEncoder;
 
    @Mock
    private AuthenticationManager authenticationManager;
 
    @Mock
    private JwtUtils jwtUtils;
 
    @InjectMocks
    private CustomerServiceImpl customerService;
 
    private Customer customer;
    private CustomerDto customerDto;
 
    @BeforeEach
    void setUp() {
        customer = new Customer(
                1,
                CustomerRole.USER,
                "John Doe",
                "john@example.com",
                "password123",
                "1234567890",
                "123 Street, City"
        );
 
        customerDto = new CustomerDto(
                1,
                CustomerRole.USER,
                "John Doe",
                "john@example.com",
                "password123",
                "1234567890",
                "123 Street, City"
        );
    }
 
    @Test
    void testGetAllCustomers() {
        List<Customer> customerList = List.of(customer);
 
        when(customerRepository.findAll()).thenReturn(customerList);
        when(modelMapper.map(customer, CustomerDto.class)).thenReturn(customerDto);
 
        List<CustomerDto> result = customerService.getAllCustomers();
 
        assertNotNull(result);
        assertEquals(1, result.size());
        assertEquals("John Doe", result.get(0).getName());
 
        verify(customerRepository, times(1)).findAll();
    }
 
    @Test
    void testGetCustomerById_Success() {
        when(customerRepository.findById(1)).thenReturn(Optional.of(customer));
        when(modelMapper.map(customer, CustomerDto.class)).thenReturn(customerDto);
 
        CustomerDto result = customerService.getCustomerById(1);
 
        assertNotNull(result);
        assertEquals("John Doe", result.getName());
        verify(customerRepository, times(1)).findById(1);
    }
 
    @Test
    void testGetCustomerById_NotFound() {
        when(customerRepository.findById(99)).thenReturn(Optional.empty());
 
        Exception exception = assertThrows(IdNotFoundException.class, () -> {
            customerService.getCustomerById(99);
        });
 
        assertEquals("Id not found: 99", exception.getMessage());
        verify(customerRepository, times(1)).findById(99);
    }
 
    @Test
    void testCreateCustomer_Success() {
        Customer customerToSave = new Customer();
        customerToSave.setPassword("encodedPassword");
 
        when(modelMapper.map(customerDto, Customer.class)).thenReturn(customer);
        when(passwordEncoder.encode(customerDto.getPassword())).thenReturn("encodedPassword");
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
        when(modelMapper.map(customer, CustomerDto.class)).thenReturn(customerDto);
 
        CustomerDto result = customerService.createCustomer(customerDto);
 
        assertNotNull(result);
        assertEquals(customerDto.getEmail(), result.getEmail());
 
        verify(customerRepository, times(1)).save(any(Customer.class));
    }
 
    @Test
    void testDeleteCustomer_Success() {
        when(customerRepository.existsById(1)).thenReturn(true);
 
        assertDoesNotThrow(() -> customerService.deleteCustomer(1));
 
        verify(customerRepository, times(1)).existsById(1);
        verify(customerRepository, times(1)).deleteById(1);
    }
 
    
    @Test
    void testDeleteCustomer_NotFound() {
        when(customerRepository.existsById(99)).thenReturn(false);
 
        Exception exception = assertThrows(IdNotFoundException.class, () -> {
            customerService.deleteCustomer(99);
        });
 
        assertEquals("Customer with ID 99 not found", exception.getMessage());
        verify(customerRepository, times(1)).existsById(99);
    }
    @Test
    void testCheckLogin_Success() {
        CustomerLoginDto loginDto = new CustomerLoginDto(
                "john@example.com",
                "password123"
        );
 
        Authentication authentication = mock(Authentication.class);
        when(authentication.isAuthenticated()).thenReturn(true);
 
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(authentication);
        when(customerRepository.findByEmail(loginDto.getEmail()))
                .thenReturn(Optional.of(customer));
        when(jwtUtils.generateToken(loginDto.getEmail()))
                .thenReturn("dummy-jwt-token");
 
        ResponseEntity<JwtDto> response = customerService.checkLogin(loginDto);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("dummy-jwt-token", response.getBody().getJwtToken());
 
        verify(authenticationManager, times(1))
                .authenticate(any(UsernamePasswordAuthenticationToken.class));
        verify(customerRepository, times(1)).findByEmail(loginDto.getEmail());
    }
    @Test
    void testCheckLogin_CustomerNotFound() {
        CustomerLoginDto loginDto = new CustomerLoginDto(
                "john@example.com",
                "password123"
        );
 
        Authentication authentication = mock(Authentication.class);
 
        when(authenticationManager.authenticate(any(UsernamePasswordAuthenticationToken.class)))
                .thenReturn(authentication);
        when(customerRepository.findByEmail(loginDto.getEmail()))
                .thenReturn(Optional.empty());
 
        Exception exception = assertThrows(ApiException.class, () -> {
            customerService.checkLogin(loginDto);
        });
 
        assertEquals("No user found with email: john@example.com", exception.getMessage());
 
        verify(authenticationManager, times(1))
                .authenticate(any(UsernamePasswordAuthenticationToken.class));
        verify(customerRepository, times(1)).findByEmail(loginDto.getEmail());
    }
 
    @Test
    void testChangeUserDetails_Success() {
        when(customerRepository.findById(customerDto.getCustomerId()))
                .thenReturn(Optional.of(customer));
        when(customerRepository.save(any(Customer.class))).thenReturn(customer);
 
        ResponseEntity<Customer> response = customerService.changeUserDetails(customerDto);
 
        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("John Doe", response.getBody().getName());
 
        verify(customerRepository, times(1)).findById(customerDto.getCustomerId());
        verify(customerRepository, times(1)).save(any(Customer.class));
    }
 
    
    @Test
    void testChangeUserDetails_NotFound() {
        when(customerRepository.findById(99)).thenReturn(Optional.empty());
 
        Exception exception = assertThrows(ApiException.class, () -> {
            customerService.changeUserDetails(new CustomerDto(
                    99, CustomerRole.USER, "Name", "email", "pass", "1234567890", "address"
            ));
        });
 
        assertEquals("No user found with id: 99", exception.getMessage());
        verify(customerRepository, times(1)).findById(99);
    }
    
}*/