package com.cts.food_delivery_app.dto;
import org.junit.jupiter.api.Test;
import com.cts.food_delivery_app.enums.CustomerRole;
import static org.junit.jupiter.api.Assertions.*;
class CustomerDtoTest {
    @Test
    void testCustomerDto_GettersAndSetters() {
        CustomerDto customer = new CustomerDto();
        customer.setCustomerId(1);
        customer.setRole(CustomerRole.USER);
        customer.setName("John Doe");
        customer.setEmail("john@example.com");
        customer.setPassword("John@123");
        customer.setPhone("1234567890");
        customer.setAddress("123 Street");
        assertEquals(1, customer.getCustomerId());
        assertEquals(CustomerRole.USER, customer.getRole());
        assertEquals("John Doe", customer.getName());
        assertEquals("john@example.com", customer.getEmail());
        assertEquals("John@123", customer.getPassword());
        assertEquals("1234567890", customer.getPhone());
        assertEquals("123 Street", customer.getAddress());
    }
    @Test
    void testCustomerDto_AllArgsConstructor() {
        CustomerDto customer = new CustomerDto(1, CustomerRole.USER, "John Doe", "john@example.com", "John@123", "1234567890", "123 Street");
        assertEquals(1, customer.getCustomerId());
        assertEquals(CustomerRole.USER, customer.getRole());
        assertEquals("John Doe", customer.getName());
        assertEquals("john@example.com", customer.getEmail());
        assertEquals("John@123", customer.getPassword());
        assertEquals("1234567890", customer.getPhone());
        assertEquals("123 Street", customer.getAddress());
    }
}