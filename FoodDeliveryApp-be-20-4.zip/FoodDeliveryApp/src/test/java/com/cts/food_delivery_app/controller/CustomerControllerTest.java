package com.cts.food_delivery_app.controller;

import com.cts.food_delivery_app.controllers.CustomerController;
import com.cts.food_delivery_app.dto.CustomerDto;
import com.cts.food_delivery_app.entities.Customer;
import com.cts.food_delivery_app.service.CustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class CustomerControllerTest {

    @Mock
    private CustomerService customerService;

    @InjectMocks
    private CustomerController customerController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

   
    @Test
    void testDeleteCustomer() {
        int customerId = 1;
        Customer mockCustomer = new Customer();
        mockCustomer.setCustomerId(customerId);
        mockCustomer.setName("John Doe");
        mockCustomer.setEmail("john.doe@example.com");

        // Mock the behavior of finding and deleting the customer
        when(customerService.deleteCustomer(customerId)).thenReturn(ResponseEntity.ok(mockCustomer));

        // Call the controller method
        ResponseEntity<String> response = customerController.deleteCustomer(customerId);

        // Verify the response
        assertEquals(HttpStatus.OK, response.getStatusCode()); // Ensure HTTP status is 200
        assertEquals("Deleted successfully", response.getBody()); // Ensure response body is correct

        // Verify that the service method was called once
        verify(customerService, times(1)).deleteCustomer(customerId);
    }



    @Test
    void testGetAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        customers.add(new Customer());
        when(customerService.getAllCustomers()).thenReturn(customers);

        ResponseEntity<List<Customer>> response = customerController.getAllCustomers();

        assertEquals(200, response.getStatusCode());
        assertEquals(1, response.getBody().size());
        verify(customerService, times(1)).getAllCustomers();
    }

    @Test
    void testGetCustomerById() {
        int customerId = 1;
        Customer customer = new Customer();
        when(customerService.getCustomerById(customerId)).thenReturn(customer);

        ResponseEntity<Customer> response = customerController.getCustomerById(customerId);

        assertEquals(200, response.getStatusCode());
        assertEquals(customer, response.getBody());
        verify(customerService, times(1)).getCustomerById(customerId);
    }

    @Test
    void testGetCustomerById_NotFound() {
        int customerId = 1;
        when(customerService.getCustomerById(customerId)).thenReturn(null);

        ResponseEntity<Customer> response = customerController.getCustomerById(customerId);

        assertEquals(404, response.getStatusCode());
        verify(customerService, times(1)).getCustomerById(customerId);
    }

    @Test
    void testChangeUserDetails() {
        CustomerDto customerDto = new CustomerDto();
        Customer customer = new Customer();
        ResponseEntity<Customer> expectedResponse = ResponseEntity.ok(customer);
        when(customerService.changeUserDetails(customerDto)).thenReturn(expectedResponse);

        ResponseEntity<Customer> response =  customerController.changeUserDetails(customerDto);

        assertEquals(expectedResponse, response);
        verify(customerService, times(1)).changeUserDetails(customerDto);
    }
}



/* package com.cts.food_delivery_app.controller;
 
import com.cts.food_delivery_app.controllers.CustomerController;
import com.cts.food_delivery_app.dto.CustomerDto;
import com.cts.food_delivery_app.enums.CustomerRole;
import com.cts.food_delivery_app.exceptions.IdNotFoundException;
import com.cts.food_delivery_app.service.CustomerService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
 
import java.util.Arrays;
import java.util.List;
 
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
 
@ExtendWith(MockitoExtension.class)
class CustomerControllerTest {

    private MockMvc mockMvc;
 
    @Mock
    private CustomerService customerService;
 
    @InjectMocks
    private CustomerController customerController;
 
    private CustomerDto customerDto;
 
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(customerController).build();
        customerDto = new CustomerDto(1,CustomerRole.USER, "John Doe", "john@example.com","John@123", "1234567890", "123 Street");
    }
 
    //Get All Customers
    @Test
    void testGetAllCustomers() throws Exception {
        List<CustomerDto> customers = Arrays.asList(customerDto);
        when(customerService.getAllCustomers()).thenReturn(customers);
 
        mockMvc.perform(get("/customers/getAll"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.size()").value(1))
                .andExpect(jsonPath("$[0].name").value("John Doe"));
 
        verify(customerService, times(1)).getAllCustomers();
    }
 
    //Get Customer by Valid ID
    @Test
    void testGetCustomerById_ValidId() throws Exception {
        when(customerService.getCustomerById(1)).thenReturn(customerDto);
 
        mockMvc.perform(get("/customers/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John Doe"));
 
        verify(customerService, times(1)).getCustomerById(1);
    }
 
    //Get Customer by Invalid ID (Not Found)
    @Test
    void testGetCustomerById_InvalidId() throws Exception {
        when(customerService.getCustomerById(99)).thenThrow(new IdNotFoundException("Customer with ID 99 not found"));
 
        mockMvc.perform(get("/customers/99"))
                .andExpect(status().isNotFound());
 
        verify(customerService, times(1)).getCustomerById(99);
    }
 
     // Test: Create New Customer
    @Test
    void testCreateCustomer() throws Exception {
        when(customerService.createCustomer(any(CustomerDto.class))).thenReturn(customerDto);
 
        mockMvc.perform(post("/customers/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("{\"customerId\":1,\"role\":\"USER\",\"name\":\"John Doe\",\"email\":\"john@example.com\",\"password\":\"John@123\",\"phone\":\"1234567890\",\"address\":\"123 Street\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.name").value("John Doe"));
 
        verify(customerService, times(1)).createCustomer(any(CustomerDto.class));
    }
 
    
    //Test: Delete Customer by Valid ID
    @Test
    void testDeleteCustomer_ValidId() throws Exception {
        doNothing().when(customerService).deleteCustomer(1);
 
        mockMvc.perform(delete("/customers/1"))
                .andExpect(status().isOk())
                .andExpect(content().string("Deleted successfully"));
 
        verify(customerService, times(1)).deleteCustomer(1);
    }
 
     //Delete Customer by Invalid ID (Not Found)
    @Test
    void testDeleteCustomer_InvalidId() throws Exception {
        doThrow(new IdNotFoundException("Customer with ID 99 not found")).when(customerService).deleteCustomer(99);
 
        mockMvc.perform(delete("/customers/99"))
                .andExpect(status().isNotFound());
 
        verify(customerService, times(1)).deleteCustomer(99);
    }
    
	
}*/